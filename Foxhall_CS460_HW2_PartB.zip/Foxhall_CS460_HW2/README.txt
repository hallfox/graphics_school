Taylor Foxhall
tfoxhal1@binghamton.edu


Control notes:

Painting mode (default):

Mouse clicking and drawing works like last time. Left click to start drawing
and adding points, right click to stop.

u - Undos the last drawing
c - toggle clipping mode

Clipping mode:

This mode allows you to work with the polygons you drew and clips them in the big window, called the Clipping Window.
The big window is viewport mapped to the smaller one, called the Viewport. You can change the size of the Viewport
and Clipping Window by dragging the black box in the bottom corner. If you click and drag in the Clipping Window, you can
also pan it around the polygon.

f - fill region


Note:

I noticed the Clipping Window can get buggy if you move it outside the OpenGL window or resize it too small. Please forgive
the bugs, but assure you the requirements of the assignment have all been implemented and are demonstratable.
