Taylor Foxhall
tfoxhal1@binghamton.edu


Control notes:

n - Next scene

===Flower scene===
Click and drag - move the center vertex
r, R - rotate the image 30 or -30 degrees

===Teapot scene===
Click and drag - rotate teapot
z, Z - zoom in and out from the teapot
