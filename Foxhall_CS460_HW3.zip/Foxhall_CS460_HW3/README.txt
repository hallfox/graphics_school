Taylor Foxhall
tfoxhal1@binghamton.edu


Control notes:

Up, Down - Pitch
Left, Right - Yaw
r, R - Roll
w - Zoom in
s - Zoom out
n - Go to next scene
g, G - rotate lever
